# Progressive Web Apps

Ini merupakan aplikasi PWA sederhana yang menggunakan fitur Add to Home Screen dan melakukan otomatis cache terhadap beberapa file yang dibutuhkan. Aplikasi ini memiliki 2 halaman untuk testing yaitu `index.html` dan `about.html` 
Didalam ini
## How to run it
 - Instal plugin [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) yang tersedia di Visual Studio Code. 
 - Buka file index.html
 - Klik kanan > Open with Live Server
 - Buka browser Chrome (Rekomendasi Versi 85 atau diatasnya.)
 - Akses URL `http://localhost:5500/index.html`
