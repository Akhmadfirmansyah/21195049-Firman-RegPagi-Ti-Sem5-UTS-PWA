const CACHE_NAME = 'UTS-pwa';
const toCache = [
    '/',
    '/index.html',
    '/service-worker.js',
    'assets/css/style.css',
    'assets/js/web.webmanifest',
    'assets/js/register.js',
    'assets/img/icon.png',
    'assets/js/main.js',
    'assets/css/bootstrap.min.css',
    'assets/lib/owlcarousel/assets/owl.carousel.min.css',
    'assets/lib/lightbox/css/lightbox.min.css',
    'assets/lib/animate/animate.min.css',
    'assets/lib/wow/wow.min.js',
    'assets/lib/typed/typed.min.js',
    'assets/lib/easing/easing.min.js',
    'assets/lib/waypoints/waypoints.min.js',
    'assets/lib/counterup/counterup.min.js',
    'assets/lib/owlcarousel/owl.carousel.min.js',
    'assets/lib/isotope/isotope.pkgd.min.js',
    'assets/lib/lightbox/js/lightbox.min.js',
    'assets/lib/lightbox/images/close.png',
    'assets/lib/lightbox/images/loading.gif',
    'assets/lib/lightbox/images/next.png',
    'assets/lib/lightbox/images/prev.png',
    'assets/img/bola.jpg',
    'assets/img/fauziah.jpg',
    'assets/img/firman.webp',
    'assets/img/hadroh.jpg',
    'assets/img/keluarga.jpg',
    'assets/img/kuliah.jpg',
    'assets/img/kuliah1.jpg',
    'assets/img/mahasiswa.jpg',
    'assets/img/sabit.jpg',
    'assets/img/turing.jpg',
];

self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME)
        .then(function(cache) {
            return cache.addAll(toCache)
        })
        .then(self.skipWaiting())
    )
})

self.addEventListener('fetch', function(event) {
    event.respondWith(
        fetch(event.request)
        .catch(() => {
            return caches.open(CACHE_NAME)
            .then((cache) => {
                return cache.match(event.request)
            })
        })
    )
})

self.addEventListener('activate', function(event) {
    event.waitUntil(
        caches.keys()
        .then((keyList) => {
            return Promise.all(keyList.map((key) => {
                if (key !== CACHE_NAME) {
                    console.log('[ServiceWorker] Hapus cache lama', key)
                    return caches.delete(key)
                }
            }))
        })
        .then(() => self.clients.claim())
    )
})
